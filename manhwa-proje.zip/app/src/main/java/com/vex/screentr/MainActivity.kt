package com.vex.screentr

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val REQ_CAPTURE = 100
    private lateinit var keyBox: EditText
    private lateinit var modelBox: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        val info = TextView(this).apply {
            text = "Gemini API anahtarını yaz, Başlat'a bas, izinleri ver, sonra manhwa'yı aç ve kaydır.\n" +
                    "Kaydırmayı bırakınca ekran çevrilir. Görüntü Gemini'ye gönderilir, uygulama hiçbir görüntü veya çeviri kaydetmez."
            textSize = 15f
        }
        keyBox = EditText(this).apply {
            hint = "Gemini API anahtarı"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        modelBox = EditText(this).apply {
            hint = "Model adı"
            setText(prefs.getString("model", "gemini-3.5-flash"))
        }
        val start = Button(this).apply {
            text = "Başlat"
            setOnClickListener {
                val k = keyBox.text.toString().trim()
                val m = modelBox.text.toString().trim()
                if (k.isEmpty() || m.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Anahtar ve model adı boş olamaz", Toast.LENGTH_SHORT).show()
                } else {
                    prefs.edit().putString("key", k).putString("model", m).apply()
                    begin()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Durdur"
            setOnClickListener {
                startService(Intent(this@MainActivity, ScreenService::class.java)
                    .setAction(ScreenService.ACTION_STOP))
            }
        }
        root.addView(info)
        root.addView(keyBox)
        root.addView(modelBox)
        root.addView(start)
        root.addView(stop)
        setContentView(root)

        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Önce 'diğer uygulamaların üzerinde göster' iznini ver", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenService::class.java)
                .setAction(ScreenService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data)
                .putExtra("key", keyBox.text.toString().trim())
                .putExtra("model", modelBox.text.toString().trim())
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
