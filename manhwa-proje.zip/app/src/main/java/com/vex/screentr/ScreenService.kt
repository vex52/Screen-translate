package com.vex.screentr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class ScreenService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        private const val CH = "screentr"

        // Ayarlanabilir değerler
        private const val POLL_MS = 250L
        private const val SCROLL_THRESHOLD = 4.0   // bundan fazla fark = kaydırıldı
        private const val STABLE_THRESHOLD = 1.5   // bundan az fark = ekran durdu
        private const val STABLE_POLLS = 2         // kaç ölçüm durgun olmalı
        private const val SEND_WIDTH = 1080        // Gemini'ye giden görüntü genişliği

        private const val PROMPT =
            "Bu bir manhwa/webtoon ekran görüntüsü. Görüntüdeki tüm konuşma balonlarını, düşünce kutularını, " +
            "anlatım kutularını ve diyalog yazılarını bul. Her fontu, el yazısını ve eğik yazıyı oku. " +
            "Ses efektlerini, filigranları ve uygulama arayüzü yazılarını (saat, menü, düğmeler) atla. " +
            "Her yazıyı akıcı, doğal ve konuşma diline uygun Türkçeye çevir. Karakterin üslubunu koru, " +
            "çeviri balona sığacak kadar kısa olsun. " +
            "SADECE şu biçimde bir JSON dizisi döndür, başka hiçbir şey yazma: " +
            "[{\"box_2d\":[ymin,xmin,ymax,xmax],\"tr\":\"Türkçe çeviri\"}] " +
            "box_2d koordinatları 0 ile 1000 arasında normalize edilmiş olsun ve o yazının (balonun metin alanının) " +
            "yerini göstersin. Çevrilecek yazı yoksa [] döndür."
    }

    private enum class State { IDLE, BUSY, SHOWN }

    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var wm: WindowManager? = null

    private var apiKey = ""
    private var model = ""
    private var width = 0
    private var height = 0
    private var state = State.IDLE
    private var prevSig: IntArray? = null
    private var refSig: IntArray? = null
    private var stableCount = 0
    private var ignoreUntil = 0L
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutdown(); return START_NOT_STICKY }
            ACTION_START -> {
                startForegroundNotif()
                val code = intent.getIntExtra("code", 0)
                val data = intent.getParcelableExtra<Intent>("data")
                apiKey = intent.getStringExtra("key") ?: ""
                model = intent.getStringExtra("model") ?: ""
                if (data != null && apiKey.isNotEmpty()) setup(code, data) else shutdown()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNotif() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Ekran çevirici", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, ScreenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("Manhwa Çevir çalışıyor")
            .setContentText("Durdurmak için dokun")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(stopPi)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun setup(code: Int, data: Intent) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val bounds = wm!!.maximumWindowMetrics.bounds
        width = bounds.width()
        height = bounds.height()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { shutdown() } }
        }, main)

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "screentr", width, height, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )

        overlay = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm!!.addView(overlay, lp)

        Toast.makeText(this, "Hazır. Manhwa'yı aç ve kaydır.", Toast.LENGTH_SHORT).show()
        running = true
        main.postDelayed(loop, POLL_MS)
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try { tick() } catch (_: Throwable) { }
            main.postDelayed(this, POLL_MS)
        }
    }

    private fun tick() {
        val img = reader?.acquireLatestImage() ?: return
        val bmp: Bitmap
        try {
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * width
            val tmp = Bitmap.createBitmap(width + rowPadding / plane.pixelStride, height, Bitmap.Config.ARGB_8888)
            tmp.copyPixelsFromBuffer(plane.buffer)
            bmp = if (rowPadding == 0) tmp else Bitmap.createBitmap(tmp, 0, 0, width, height).also { tmp.recycle() }
        } finally {
            img.close()
        }

        val sig = signature(bmp)
        val now = System.currentTimeMillis()

        if (now < ignoreUntil) { prevSig = sig; bmp.recycle(); return }

        when (state) {
            State.BUSY -> bmp.recycle()
            State.SHOWN -> {
                if (refSig == null) {
                    refSig = sig
                } else if (diff(sig, refSig!!) > SCROLL_THRESHOLD) {
                    overlay?.clear()
                    state = State.IDLE
                    refSig = null
                    prevSig = null
                    stableCount = 0
                    ignoreUntil = now + 250
                }
                bmp.recycle()
            }
            State.IDLE -> {
                val p = prevSig
                stableCount = if (p != null && diff(sig, p) < STABLE_THRESHOLD) stableCount + 1 else 0
                prevSig = sig
                if (stableCount >= STABLE_POLLS) {
                    state = State.BUSY
                    stableCount = 0
                    process(bmp)
                } else {
                    bmp.recycle()
                }
            }
        }
    }

    // Görüntü yalnızca RAM'de işlenir, Gemini'ye gönderilir, hiçbir yere kaydedilmez.
    private fun process(bmp: Bitmap) {
        val key = apiKey
        val mdl = model
        io.execute {
            var items: List<OverlayView.Item> = emptyList()
            var err: String? = null
            try {
                val sw = SEND_WIDTH
                val sh = (bmp.height * sw / bmp.width.toFloat()).toInt()
                val scaled = Bitmap.createScaledBitmap(bmp, sw, sh, true)
                val bos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                if (scaled !== bmp) scaled.recycle()
                bmp.recycle()
                val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                items = parse(callGemini(key, mdl, b64))
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
                try { bmp.recycle() } catch (_: Throwable) { }
            }
            main.post {
                if (err != null) {
                    Toast.makeText(this, "Hata: " + err.take(160), Toast.LENGTH_LONG).show()
                }
                finishShown(items)
            }
        }
    }

    private fun callGemini(key: String, mdl: String, b64: String): String {
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray()
                    .put(JSONObject().put("text", PROMPT))
                    .put(JSONObject().put("inline_data", JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", b64))))
            }))
            put("generationConfig", JSONObject()
                .put("responseMimeType", "application/json")
                .put("temperature", 0.3))
        }.toString()

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$mdl:generateContent")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 90000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (_: Throwable) { text }
                throw RuntimeException("HTTP $code: $msg")
            }
            val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
            }
            return sb.toString()
        } finally {
            c.disconnect()
        }
    }

    private fun parse(text: String): List<OverlayView.Item> {
        val s = text.indexOf('[')
        val e = text.lastIndexOf(']')
        if (s < 0 || e <= s) return emptyList()
        val arr = JSONArray(text.substring(s, e + 1))
        val out = ArrayList<OverlayView.Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val b = o.optJSONArray("box_2d") ?: continue
            val tr = o.optString("tr").trim()
            if (b.length() < 4 || tr.isEmpty()) continue
            val y0 = b.getDouble(0); val x0 = b.getDouble(1)
            val y1 = b.getDouble(2); val x1 = b.getDouble(3)
            val l = (min(x0, x1) * width / 1000).toInt()
            val r = (max(x0, x1) * width / 1000).toInt()
            val t = (min(y0, y1) * height / 1000).toInt()
            val bt = (max(y0, y1) * height / 1000).toInt()
            val rect = Rect(l, t, r, bt)
            if (rect.width() < 30 || rect.height() < 20) continue
            out.add(OverlayView.Item(rect, tr))
        }
        return out
    }

    private fun finishShown(items: List<OverlayView.Item>) {
        if (!running) return
        overlay?.setItems(items)
        refSig = null
        prevSig = null
        ignoreUntil = System.currentTimeMillis() + 300
        state = State.SHOWN
    }

    // Ekranı küçük bir parlaklık ızgarasına indirger (hafızada, kaydedilmez)
    private fun signature(b: Bitmap): IntArray {
        val w = 48
        val h = 96
        val s = Bitmap.createScaledBitmap(b, w, h, false)
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        if (s !== b) s.recycle()
        return IntArray(px.size) { i ->
            val c = px[i]
            (((c shr 16) and 0xFF) * 3 + ((c shr 8) and 0xFF) * 6 + (c and 0xFF)) / 10
        }
    }

    private fun diff(a: IntArray, b: IntArray): Double {
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum.toDouble() / a.size
    }

    private fun shutdown() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { overlay?.let { wm?.removeView(it) } } catch (_: Throwable) { }
        overlay = null
        display?.release(); display = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}
