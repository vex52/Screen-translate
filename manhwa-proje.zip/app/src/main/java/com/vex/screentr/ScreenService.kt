package com.vex.screentr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class ScreenService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        private const val CH = "screentr"

        // Ayarlanabilir değerler
        private const val POLL_MS = 350L
        private const val SCROLL_THRESHOLD = 4.0   // bundan fazla fark = kaydırıldı
        private const val STABLE_THRESHOLD = 1.5   // bundan az fark = ekran durdu
        private const val STABLE_POLLS = 2         // kaç ölçüm durgun olmalı
        private const val CAPTURE_WIDTH = 1080     // yakalanan ve Gemini'ye giden görüntü genişliği

        private const val PROMPT =
            "Bu bir manhwa/webtoon ekran görüntüsü. Görüntüdeki tüm konuşma balonlarını, düşünce kutularını, " +
            "anlatım kutularını ve diyalog yazılarını bul. Her fontu, el yazısını ve eğik yazıyı oku. " +
            "Ses efektlerini, filigranları ve uygulama arayüzü yazılarını (saat, menü, düğmeler) atla. " +
            "Her yazıyı akıcı, doğal ve konuşma diline uygun Türkçeye çevir. Karakterin üslubunu koru, " +
            "çeviri balona sığacak kadar kısa olsun. " +
            "SADECE şu biçimde bir JSON dizisi döndür, başka hiçbir şey yazma: " +
            "[{\"box_2d\":[ymin,xmin,ymax,xmax],\"tr\":\"Türkçe çeviri\"}] " +
            "box_2d koordinatları 0 ile 1000 arasında normalize edilmiş olsun ve o yazının (balonun metin alanının) " +
            "yerini göstersin. Çevrilecek yazı yoksa [] döndür."
    }

    private enum class State { IDLE, BUSY, SHOWN }

    private val main = Handler(Looper.getMainLooper())
    private val bgThread = HandlerThread("cap").also { it.start() }
    private val bg = Handler(bgThread.looper)
    private val io = Executors.newSingleThreadExecutor()

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var overlayAttached = false   // yalnızca ana iş parçacığında
    private var wm: WindowManager? = null

    private var apiKey = ""
    private var model = ""
    private var screenW = 0
    private var screenH = 0
    private var capW = 0
    private var capH = 0

    // Aşağıdakiler yalnızca bg iş parçacığında kullanılır
    private var state = State.IDLE
    private var prevSig: IntArray? = null
    private var refSig: IntArray? = null
    private var stableCount = 0
    private var ignoreUntil = 0L

    @Volatile private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutdown(); return START_NOT_STICKY }
            ACTION_START -> {
                startForegroundNotif()
                val code = intent.getIntExtra("code", 0)
                val data = intent.getParcelableExtra<Intent>("data")
                apiKey = intent.getStringExtra("key") ?: ""
                model = intent.getStringExtra("model") ?: ""
                if (data != null && apiKey.isNotEmpty()) setup(code, data) else shutdown()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNotif() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Ekran çevirici", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, ScreenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("Manhwa Çevir çalışıyor")
            .setContentText("Durdurmak için dokun")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(stopPi)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun setup(code: Int, data: Intent) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val bounds = wm!!.maximumWindowMetrics.bounds
        screenW = bounds.width()
        screenH = bounds.height()
        capW = min(CAPTURE_WIDTH, screenW)
        capH = (screenH.toLong() * capW / screenW).toInt()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { shutdown() } }
        }, main)

        // Ekran düşük çözünürlükte yakalanır: bellek ve işlemci yükü çok azalır
        reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "screentr", capW, capH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )

        overlay = OverlayView(this)
        overlayParams = WindowManager.LayoutParams(
            screenW, screenH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Android 12+ dokunuşları, opaklığı 0.8'den büyük pencerelerin içinden geçirmez.
            // Bu yüzden altındaki uygulamaya dokunabilmen için 0.8'in altında tutuyoruz.
            alpha = 0.79f
        }

        Toast.makeText(this, "Hazır. Manhwa'yı aç ve kaydır.", Toast.LENGTH_SHORT).show()
        running = true
        bg.postDelayed(loop, POLL_MS)
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try { tick() } catch (_: Throwable) { }
            if (running) bg.postDelayed(this, POLL_MS)
        }
    }

    private fun tick() {
        val img = reader?.acquireLatestImage() ?: return
        var jpegB64: String? = null
        try {
            val plane = img.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pixStride = plane.pixelStride

            // Ekranın küçük bir ızgarasını doğrudan arabellekten örnekle (bitmap oluşturmadan)
            val gw = 48
            val gh = 96
            val sig = IntArray(gw * gh)
            var k = 0
            for (r in 0 until gh) {
                val y = (r * capH) / gh
                for (c in 0 until gw) {
                    val x = (c * capW) / gw
                    val o = y * rowStride + x * pixStride
                    val rr = buf.get(o).toInt() and 0xFF
                    val gg = buf.get(o + 1).toInt() and 0xFF
                    val bb = buf.get(o + 2).toInt() and 0xFF
                    sig[k++] = (rr * 3 + gg * 6 + bb) / 10
                }
            }

            val now = System.currentTimeMillis()
            if (now < ignoreUntil) { prevSig = sig; return }

            when (state) {
                State.BUSY -> { }
                State.SHOWN -> {
                    if (refSig == null) {
                        refSig = sig
                    } else if (diff(sig, refSig!!) > SCROLL_THRESHOLD) {
                        main.post { hideOverlay() }
                        state = State.IDLE
                        refSig = null
                        prevSig = null
                        stableCount = 0
                        ignoreUntil = now + 400
                    }
                }
                State.IDLE -> {
                    val p = prevSig
                    stableCount = if (p != null && diff(sig, p) < STABLE_THRESHOLD) stableCount + 1 else 0
                    prevSig = sig
                    if (stableCount >= STABLE_POLLS) {
                        stableCount = 0
                        state = State.BUSY
                        // Kareyi JPEG'e çevir (yalnızca RAM'de)
                        val tmp = Bitmap.createBitmap(rowStride / pixStride, capH, Bitmap.Config.ARGB_8888)
                        buf.rewind()
                        tmp.copyPixelsFromBuffer(buf)
                        val bmp = Bitmap.createBitmap(tmp, 0, 0, capW, capH)
                        if (bmp !== tmp) tmp.recycle()
                        val bos = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                        bmp.recycle()
                        jpegB64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                    }
                }
            }
        } finally {
            img.close()
        }
        jpegB64?.let { send(it) }
    }

    // Görüntü yalnızca RAM'de işlenir, Gemini'ye gönderilir, hiçbir yere kaydedilmez.
    private fun send(b64: String) {
        val key = apiKey
        val mdl = model
        io.execute {
            var items: List<OverlayView.Item> = emptyList()
            var err: String? = null
            val t0 = System.currentTimeMillis()
            try {
                val raw = try {
                    callGemini(key, mdl, b64, true)
                } catch (e: RuntimeException) {
                    val m = e.message ?: ""
                    if (m.contains("HTTP 400") && m.contains("think", ignoreCase = true)) callGemini(key, mdl, b64, false)
                    else throw e
                }
                items = parse(raw)
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            val sec = (System.currentTimeMillis() - t0) / 1000
            if (err != null) {
                main.post { Toast.makeText(this, "Hata ($sec sn): " + err.take(160), Toast.LENGTH_LONG).show() }
                bg.post {
                    if (!running) return@post
                    // Hata olursa kısa süre sonra kendiliğinden yeniden dene
                    refSig = null
                    prevSig = null
                    stableCount = 0
                    ignoreUntil = System.currentTimeMillis() + 8000
                    state = State.IDLE
                }
            } else {
                main.post { Toast.makeText(this, "Gemini: $sec sn, ${items.size} metin", Toast.LENGTH_SHORT).show() }
                bg.post {
                    if (!running) return@post
                    main.post { showOverlay(items) }
                    refSig = null
                    prevSig = null
                    ignoreUntil = System.currentTimeMillis() + 600
                    state = State.SHOWN
                }
            }
        }
    }

    private fun callGemini(key: String, mdl: String, b64: String, withThinking: Boolean): String {
        val body = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray()
                    .put(JSONObject().put("text", PROMPT))
                    .put(JSONObject().put("inline_data", JSONObject()
                        .put("mime_type", "image/jpeg")
                        .put("data", b64))))
            }))
            val gc = JSONObject()
                .put("responseMimeType", "application/json")
                .put("temperature", 0.3)
            if (withThinking) {
                // Modelin uzun uzun "düşünmesini" kapat: çok daha hızlı yanıt verir
                if (mdl.contains("2.5")) {
                    gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                } else if (mdl.contains("3")) {
                    gc.put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal"))
                }
            }
            put("generationConfig", gc)
        }.toString()

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$mdl:generateContent")
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray()) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try { JSONObject(text).getJSONObject("error").getString("message") } catch (_: Throwable) { text }
                throw RuntimeException("HTTP $code: $msg")
            }
            val parts = JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
            }
            return sb.toString()
        } finally {
            c.disconnect()
        }
    }

    private fun parse(text: String): List<OverlayView.Item> {
        val s = text.indexOf('[')
        val e = text.lastIndexOf(']')
        if (s < 0 || e <= s) return emptyList()
        val arr = JSONArray(text.substring(s, e + 1))
        val out = ArrayList<OverlayView.Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val b = o.optJSONArray("box_2d") ?: continue
            val tr = o.optString("tr").trim()
            if (b.length() < 4 || tr.isEmpty()) continue
            val y0 = b.getDouble(0); val x0 = b.getDouble(1)
            val y1 = b.getDouble(2); val x1 = b.getDouble(3)
            val l = (min(x0, x1) * screenW / 1000).toInt()
            val r = (max(x0, x1) * screenW / 1000).toInt()
            val t = (min(y0, y1) * screenH / 1000).toInt()
            val bt = (max(y0, y1) * screenH / 1000).toInt()
            val rect = Rect(l, t, r, bt)
            if (rect.width() < 30 || rect.height() < 20) continue
            out.add(OverlayView.Item(rect, tr))
        }
        return out
    }

    // Ana iş parçacığı: pencereyi yalnızca çeviri gösterilirken ekle,
    // kaydırırken kaldır ki dokunuşlar hiç engellenmesin.
    private fun showOverlay(items: List<OverlayView.Item>) {
        val v = overlay ?: return
        if (!running) return
        if (items.isEmpty()) { hideOverlay(); return }
        v.setItems(items)
        if (!overlayAttached) {
            try { wm?.addView(v, overlayParams); overlayAttached = true } catch (_: Throwable) { }
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        v.clear()
        if (overlayAttached) {
            try { wm?.removeView(v) } catch (_: Throwable) { }
            overlayAttached = false
        }
    }

    private fun diff(a: IntArray, b: IntArray): Double {
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum.toDouble() / a.size
    }

    private fun shutdown() {
        running = false
        bg.removeCallbacksAndMessages(null)
        main.removeCallbacksAndMessages(null)
        hideOverlay()
        overlay = null
        try { display?.release() } catch (_: Throwable) { }
        display = null
        try { reader?.close() } catch (_: Throwable) { }
        reader = null
        try { projection?.stop() } catch (_: Throwable) { }
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        bgThread.quitSafely()
        io.shutdown()
        super.onDestroy()
    }
}
