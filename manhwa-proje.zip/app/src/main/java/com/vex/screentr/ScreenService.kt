package com.vex.screentr

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

class ScreenService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        private const val CH = "screentr"

        // Ayarlanabilir değerler
        private const val POLL_MS = 250L
        private const val SCROLL_THRESHOLD = 4.0   // bundan fazla fark = kaydırıldı
        private const val STABLE_THRESHOLD = 1.5   // bundan az fark = ekran durdu
        private const val STABLE_POLLS = 2         // kaç ölçüm durgun olmalı
    }

    private enum class State { IDLE, BUSY, SHOWN }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: OverlayView? = null
    private var wm: WindowManager? = null
    private var recognizer: TextRecognizer? = null
    private var translator: Translator? = null

    private var width = 0
    private var height = 0
    private var state = State.IDLE
    private var prevSig: IntArray? = null
    private var refSig: IntArray? = null
    private var stableCount = 0
    private var ignoreUntil = 0L
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { shutdown(); return START_NOT_STICKY }
            ACTION_START -> {
                startForegroundNotif()
                val code = intent.getIntExtra("code", 0)
                val data = intent.getParcelableExtra<Intent>("data")
                if (data != null) setup(code, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundNotif() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Ekran çevirici", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, ScreenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CH)
            .setContentTitle("Manhwa Çevir çalışıyor")
            .setContentText("Durdurmak için dokun")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentIntent(stopPi)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun setup(code: Int, data: Intent) {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val bounds = wm!!.maximumWindowMetrics.bounds
        width = bounds.width()
        height = bounds.height()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { shutdown() } }
        }, main)

        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "screentr", width, height, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )

        overlay = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            width, height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm!!.addView(overlay, lp)

        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.TURKISH)
                .build()
        )

        Toast.makeText(this, "Çeviri modeli hazırlanıyor (ilk seferde internet gerekir)", Toast.LENGTH_LONG).show()
        translator!!.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                Toast.makeText(this, "Hazır. Manhwa'yı aç ve kaydır.", Toast.LENGTH_SHORT).show()
                running = true
                main.postDelayed(loop, POLL_MS)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Model indirilemedi, internetini kontrol et", Toast.LENGTH_LONG).show()
                shutdown()
            }
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            try { tick() } catch (_: Throwable) { }
            main.postDelayed(this, POLL_MS)
        }
    }

    private fun tick() {
        val img = reader?.acquireLatestImage() ?: return
        val bmp: Bitmap
        try {
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * width
            val tmp = Bitmap.createBitmap(width + rowPadding / plane.pixelStride, height, Bitmap.Config.ARGB_8888)
            tmp.copyPixelsFromBuffer(plane.buffer)
            bmp = if (rowPadding == 0) tmp else Bitmap.createBitmap(tmp, 0, 0, width, height).also { tmp.recycle() }
        } finally {
            img.close()
        }

        val sig = signature(bmp)
        val now = System.currentTimeMillis()

        if (now < ignoreUntil) { prevSig = sig; bmp.recycle(); return }

        when (state) {
            State.BUSY -> bmp.recycle()
            State.SHOWN -> {
                if (refSig == null) {
                    refSig = sig
                } else if (diff(sig, refSig!!) > SCROLL_THRESHOLD) {
                    overlay?.clear()
                    state = State.IDLE
                    refSig = null
                    prevSig = null
                    stableCount = 0
                    ignoreUntil = now + 250
                }
                bmp.recycle()
            }
            State.IDLE -> {
                val p = prevSig
                stableCount = if (p != null && diff(sig, p) < STABLE_THRESHOLD) stableCount + 1 else 0
                prevSig = sig
                if (stableCount >= STABLE_POLLS) {
                    state = State.BUSY
                    stableCount = 0
                    process(bmp)
                } else {
                    bmp.recycle()
                }
            }
        }
    }

    private fun process(bmp: Bitmap) {
        val rec = recognizer ?: return
        rec.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { result ->
                bmp.recycle()
                val blocks = result.textBlocks.filter { b ->
                    val box = b.boundingBox
                    box != null && box.width() > 40 && box.height() > 20 &&
                            b.text.count { it.isLetter() } >= 3
                }
                if (blocks.isEmpty()) { finishShown(emptyList()); return@addOnSuccessListener }

                val out = arrayOfNulls<OverlayView.Item>(blocks.size)
                var left = blocks.size
                blocks.forEachIndexed { idx, b ->
                    val src = b.text.replace("\n", " ")
                    translator!!.translate(src)
                        .addOnSuccessListener { tr -> out[idx] = OverlayView.Item(Rect(b.boundingBox!!), tr) }
                        .addOnCompleteListener {
                            left--
                            if (left == 0) finishShown(out.filterNotNull())
                        }
                }
            }
            .addOnFailureListener {
                bmp.recycle()
                finishShown(emptyList())
            }
    }

    private fun finishShown(items: List<OverlayView.Item>) {
        main.post {
            overlay?.setItems(items)
            refSig = null
            prevSig = null
            ignoreUntil = System.currentTimeMillis() + 300
            state = State.SHOWN
        }
    }

    // Ekranı küçük bir parlaklık ızgarasına indirger (hafızada, kaydedilmez)
    private fun signature(b: Bitmap): IntArray {
        val w = 48
        val h = 96
        val s = Bitmap.createScaledBitmap(b, w, h, false)
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        if (s !== b) s.recycle()
        return IntArray(px.size) { i ->
            val c = px[i]
            (((c shr 16) and 0xFF) * 3 + ((c shr 8) and 0xFF) * 6 + (c and 0xFF)) / 10
        }
    }

    private fun diff(a: IntArray, b: IntArray): Double {
        var sum = 0L
        for (i in a.indices) sum += abs(a[i] - b[i])
        return sum.toDouble() / a.size
    }

    private fun shutdown() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { overlay?.let { wm?.removeView(it) } } catch (_: Throwable) { }
        overlay = null
        display?.release(); display = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        recognizer?.close(); recognizer = null
        translator?.close(); translator = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        super.onDestroy()
    }
}
