package com.vex.screentr

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

class OverlayView(context: Context) : View(context) {

    data class Item(val rect: Rect, val text: String)

    private var items: List<Item> = emptyList()
    private val bg = Paint().apply { color = Color.argb(240, 255, 255, 255) }
    private val tp = TextPaint().apply {
        color = Color.BLACK
        isAntiAlias = true
    }

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    fun clear() {
        items = emptyList()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        for (it in items) {
            val r = it.rect
            val pad = 4
            canvas.drawRect(
                (r.left - pad).toFloat(), (r.top - pad).toFloat(),
                (r.right + pad).toFloat(), (r.bottom + pad).toFloat(), bg
            )
            val w = (r.width() + pad * 2).coerceAtLeast(40)
            var size = 44f
            var layout: StaticLayout
            while (true) {
                tp.textSize = size
                layout = StaticLayout.Builder
                    .obtain(it.text, 0, it.text.length, tp, w)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .build()
                if (layout.height <= r.height() + pad * 2 || size <= 12f) break
                size -= 2f
            }
            canvas.save()
            canvas.translate((r.left - pad).toFloat(), (r.top - pad).toFloat())
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
